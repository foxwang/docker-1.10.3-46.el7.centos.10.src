go-md2man
=========

** Work in Progress **
This still needs a lot of help to be complete, or even usable!

Uses blackfriday to process markdown into man pages.

### Usage

./md2man -in /path/to/markdownfile.md -out /manfile/output/path
